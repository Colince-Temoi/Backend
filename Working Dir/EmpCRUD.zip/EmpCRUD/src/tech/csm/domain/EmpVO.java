package tech.csm.domain;

public class EmpVO {
	private String empId;
	private String name;
	private String Sal;
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSal() {
		return Sal;
	}
	public void setSal(String sal) {
		Sal = sal;
	}
	
}
