package tech.csm.runner;

import java.util.Arrays;
import java.util.Date;
import java.util.Scanner;

import tech.csm.domain.Rectangle;
import tech.csm.domain.Student;

public class Runner {

	public static void main(String[] args) {
		System.out.println("Running!");
		Student s = new Student(101, "Abc", "Kenya", 9.0f, new Date());
		System.out.println(s.getCurr_date());
		
		Rectangle r= new Rectangle(5, 3);
		System.out.println(r);
		
		Rectangle r1= new Rectangle(5, 10);
		System.out.println(r);
		
		float area = r.findArea();
		System.out.println("Area is: "+area);
		
		float area1 = r1.findArea();
		System.out.println("Area1 is: "+area1);
		
		System.out.println(r.equals(r1));  // Comparing by reference
		System.out.println("Both rectangles are equal? "+r.isEqual(r1)); // Comparing by value.
		
		
		//Object Arrays
		Rectangle[] recArray = new Rectangle[5];
		for (int i = 0; i < recArray.length; i++) {
			System.out.println("Enter the height and width: ");
			// Like this to input the values we need to invoke the object constructor and pass the values
			recArray[i] = new Rectangle(new Scanner(System.in).nextInt(), new Scanner(System.in).nextInt());
		}
		
		System.out.println(Arrays.toString(recArray));
		
	}
}