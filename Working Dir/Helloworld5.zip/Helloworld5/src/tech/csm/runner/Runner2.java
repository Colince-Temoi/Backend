package tech.csm.runner;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import tech.csm.domain.Rectangle;
import tech.csm.domain.Rectangle2;

public class Runner2 {

	public static void main(String[] args) throws ParseException {
		
//		System.out.println("Enter you dob [yyyy-mm-dd]: ");
//		String dob = new Scanner(System.in).nextLine();
//		
//		System.out.println("Printing the inputed String date format");
//		System.out.println(dob);
//		
//		//Converting into Java date format
//		SimpleDateFormat fx = new SimpleDateFormat("yyyy-MM-dd");
//		Date d = fx.parse(dob);
//		
//		// Printing the converted date
//		System.out.println(d);
//		
////		Converting Java date back to string format that will be returned to user as response
//		SimpleDateFormat fx1 = new SimpleDateFormat("dd-mm-yyyy");
//		System.out.println(fx1.format(d));
//		
		
		
        Scanner scanner = new Scanner(System.in);

        // Input width and height from the user
        System.out.print("Enter the width of the rectangle: ");
        double width = scanner.nextDouble();

        System.out.print("Enter the height of the rectangle: ");
        double height = scanner.nextDouble();

        // Create an instance of the Rectangle class
        Rectangle2 rectangle = new Rectangle2(width, height);

        // Calculate and print the area and perimeter
        System.out.println("Area of the rectangle: " + rectangle.returnArea());
        System.out.println("Perimeter of the rectangle: " + rectangle.returnPerimeter());

        scanner.close();

		
		
	}
}