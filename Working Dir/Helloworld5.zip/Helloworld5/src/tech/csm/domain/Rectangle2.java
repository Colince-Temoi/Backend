package tech.csm.domain;

public class Rectangle2 {
    private double width;
    private double height;

    // Constructor to initialize width and height
    public Rectangle2(double width, double height) {
        this.width = width;
        this.height = height;
    }

    // Method to calculate and return the area of the rectangle
    public double returnArea() {
        return width * height;
    }

    // Method to calculate and return the perimeter of the rectangle
    public double returnPerimeter() {
        return 2 * (width + height);
    }
}




