package tech.csm.domain;

public class Rectangle {
	private int height;
	private int width;
	
	public Rectangle(int height, int width) {
		super();
		this.height = height;
		this.width = width;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	
	// Find area
	public float findArea() {
		return width*height;
	}
	
	// Check if both rectangles are equal: Comparing by value concept
	public boolean isEqual(Rectangle r1) {
		return this.findArea()==r1.findArea();
	}
	
	
	@Override
	public String toString() {
		return "Rectangle [height=" + height + ", width=" + width + "]";
	}
	
	
	
	
}
