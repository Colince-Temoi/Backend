package tech.csm.domain;

import java.util.Date;

public class Student {
	private int rollNo;
	private String name;
	private String branch;
	private float cgpa;
	private Date curr_date;

//Used as one of the ways to initailise class properties.
	public Student(int rollNo, String name, String branch, float cgpa, Date curr_date) {
		super();
		this.rollNo = rollNo;
		this.name = name;
		this.branch = branch;
		this.cgpa = cgpa;
		this.curr_date = curr_date;
	}

	public int getRollNo() {
		return rollNo;
	}

	public String getName() {
		// You can implement security here to control who accesses this hidden data
		return name;
	}

	public Date getCurr_date() {
		return curr_date;
	}

	public String getBranch() {
		// You can implement security here to control who accesses this hidden data
		return branch;
	}

	public float getCgpa() {
		// You can implement security here to control who accesses this hidden data
		return cgpa;
	}

	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", name=" + name + ", branch=" + branch + ", cgpa=" + cgpa + ", curr_date="
				+ curr_date + "]";
	}
	
}
